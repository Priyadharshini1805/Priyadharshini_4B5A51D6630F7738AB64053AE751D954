# 2.2 Implement a class called Player that represents a cricket player. The Player class should have a method called play() which prints "The player is playing cricket. Derive two classes, Batsman and Bowler, from the Player class. Override the play() method in each derived class to print "The batsman is batting" and "The bowler is bowling", respectively. Write a program to create objects of both the Batsman and Bowler classes and call the play() method for each object.
# Define the Player class
class Player:
  def play(self):
    print("The player is playing cricket.")

# Define the Batsman class,derived from Player
class Batsman(Player):
  def play(self):
    print("The Batsman is Batting.")

# Define the Bowler class,derived from Player
class Bowler(Player):
  def play(self):
    print("The Bowler is Bowling.")
    
# Create objects of the Batsman and Bowler classes
batsman=Batsman()
bowler=Bowler()
# Call the play() method for each object
batsman.play()
bowler.play()